export const Constants = {
  globalTimeout: 400_000,
  expectTimeout: 60_000,
};