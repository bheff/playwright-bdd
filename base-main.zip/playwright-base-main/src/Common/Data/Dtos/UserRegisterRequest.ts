export default class UserRegisterRequest {
  password?: string;
  username?: string;
  email?: string;
}