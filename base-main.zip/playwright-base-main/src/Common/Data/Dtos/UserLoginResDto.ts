export default class UserLoginResDto {
  token?: string;
}