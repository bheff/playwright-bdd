export default class UserRegisterResDto {
  createdAt: string;
  email: string;
  id: number;
  name: string;
  updatedAt: string;
  username: string;
}