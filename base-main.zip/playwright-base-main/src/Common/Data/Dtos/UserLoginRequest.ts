export default class UserLoginRequest {
  password?: string;
  username?: string;
  long_token?: boolean;
}