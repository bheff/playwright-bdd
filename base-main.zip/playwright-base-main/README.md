# Playwright BDD & Non BDD POC

## Playwright Template Project with BDD

- This project is a POC for a shared codebase of tests that use the Playwright runner but can be expressed through Gherkin files or plain TypeScript test files through <https://vitalets.github.io/playwright-bdd/#/>

### Installation

- ```npm i```

### Execution

- Install browsers with ```npx playwright install```

- Using VS Code: install <https://marketplace.visualstudio.com/items?itemName=ms-playwright.playwright> and
use the test runner.

- Set env variable **NO_BDD** to "1" if you want to use plain typescript tests. In that case the runner will execute whatever is within the tests folder otherwisw it will require the bddgen tool to be exexuted in order to generate the tests defined wit Gherkin within the features folder.

- Generate JS code from the .feature files ```npx bddgen```

- Using the CLI: ```npx bddgen && npx playwright test --grep "<test tag> or regex" --project=chrome```

### Project Structure

- features: Gherking test cases
- tests: Regular Playwright Tests
- .features-gen: Not tracked by git. This will be generated upon running ```npx bddgen``` or ```npm run watch:bdd``` and contains the generated test code compliant with the Playwright Test Runner.
- src: TypeScript codebase
- It's possible to use a hybrid fixture that will extend a test object based on the **NO_BDD** environment value which supports both BDD and plain Playwright fixtures. If you're using VS Code and the playwright plugin, you'll need to restart the IDE after changing the env variable. This fixture is **src\Fixtures\HybridFixtures\DemoFixture.ts**.
